'use client';

import React from 'react';

import { usePromptStore } from '@/store/usePromptStore';

export function PromptEditor() {
    const {
        prompt,
        setPrompt,
        systemPrompt,
        setSystemPrompt,
        variables,
        setVariables,
        examples,
        setExamples,
        markConfigUpdated,
    } = usePromptStore();

    const addVariable = () => {
        const newVariable = { name: '', value: '' };
        setVariables([...variables, newVariable]);
        markConfigUpdated();
    };

    const addExample = () => {
        const newExample = { input: '', output: '' };
        setExamples([...examples, newExample]);
        markConfigUpdated();
    };

    const contextTitle = 'General Interview Prep';
    const contextContent = 'No specific context provided...';

    return (
        <>
            <div className="mb-4">
                <h4 className="font-semibold mb-2">Interview Context</h4>
                <div className="bg-gray-800 p-3 rounded">
                    <p className="text-sm">{contextTitle}</p>
                    <p className="text-gray-400 text-xs mt-1">
                        {contextContent.slice(0, 100)}
                    </p>
                </div>
            </div>

            <div className="mb-4">
                <label className="block mb-1 font-semibold">System Prompt</label>
                <textarea
                    className="w-full p-2 rounded border bg-background text-white"
                    rows={2}
                    value={systemPrompt}
                    onChange={(e) => setSystemPrompt(e.target.value)}
                    placeholder="You are a helpful assistant..."
                />
            </div>

            <div className="mb-4">
                <label className="block mb-1 font-semibold">Prompt Editor</label>
                <textarea
                    className="w-full p-2 rounded border bg-background text-white"
                    rows={6}
                    value={prompt}
                    onChange={(e) => setPrompt(e.target.value)}
                    placeholder="Enter your prompt here..."
                />
                <div className="flex gap-2 mt-2">
                    <button
                        onClick={addVariable}
                        className="text-xs bg-gray-700 px-2 py-1 rounded hover:bg-gray-600"
                    >
                        + Variable
                    </button>
                    <button
                        onClick={addExample}
                        className="text-xs bg-gray-700 px-2 py-1 rounded hover:bg-gray-600"
                    >
                        + Example
                    </button>
                </div>
                <div className="mt-2 space-y-2">
                    {variables.map((variable, index) => (
                        <div key={index} className="flex gap-2">
                            <input
                                type="text"
                                value={variable.name}
                                onChange={(e) => {
                                    const newVars = [...variables];
                                    newVars[index].name = e.target.value;
                                    setVariables(newVars);
                                    markConfigUpdated();
                                }}
                                className="w-1/2 p-1 rounded border bg-gray-800"
                                placeholder="Variable name"
                            />
                            <input
                                type="text"
                                value={variable.value}
                                onChange={(e) => {
                                    const newVars = [...variables];
                                    newVars[index].value = e.target.value;
                                    setVariables(newVars);
                                    markConfigUpdated();
                                }}
                                className="w-1/2 p-1 rounded border bg-gray-800"
                                placeholder="Default value"
                            />
                        </div>
                    ))}
                </div>
                <div className="mt-4">
                    <h4 className="font-semibold mb-2">Few-shot Examples</h4>
                    {examples.map((example, index) => (
                        <div key={index} className="mb-2 p-2 bg-gray-800 rounded">
                            <input
                                type="text"
                                value={example.input}
                                onChange={(e) => {
                                    const newExamples = [...examples];
                                    newExamples[index].input = e.target.value;
                                    setExamples(newExamples);
                                    markConfigUpdated();
                                }}
                                className="w-full mb-1 p-1 rounded border bg-gray-900"
                                placeholder="Example input"
                            />
                            <input
                                type="text"
                                value={example.output}
                                onChange={(e) => {
                                    const newExamples = [...examples];
                                    newExamples[index].output = e.target.value;
                                    setExamples(newExamples);
                                    markConfigUpdated();
                                }}
                                className="w-full p-1 rounded border bg-gray-900"
                                placeholder="Desired output"
                            />
                        </div>
                    ))}
                </div>
            </div>
        </>
    );
}
